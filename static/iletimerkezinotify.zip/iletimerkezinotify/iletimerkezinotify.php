<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/vendor/autoload.php';

use IMN\Module\{Install, Uninstall};
use IMN\SMS\{Api, SMS};

class Iletimerkezinotify extends Module
{
    protected $config_form = false;
    public $name = 'iletimerkezinotify';
    public $tab = 'advertising_marketing';
    public $version = '1.0.0';
    public $author = 'iletiMerkezi';
    public $need_instance = 0;
    public $bootstrap = true;
    public $ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];
    private $serviceContainer;
    private $entityManager;
    private $hookToInstall = [
        'actionObjectAddAfter',
        'actionOrderStatusPostUpdate',
        'actionAdminOrdersTrackingNumberUpdate'
    ];

    public function __construct()
    {
        parent::__construct();

        $this->displayName = $this->trans('iletiMerkezi Notify', [], 'Modules.Iletimerkezinotify.Admin');
        $this->description = $this->trans('Send SMS to your customers when order status changes.', [], 'Modules.Iletimerkezinotify.Admin');
        $this->confirmUninstall = $this->trans('Are you sure you want to uninstall?', [], 'Modules.Iletimerkezinotify.Admin');
        $this->entityManager = $this->get('doctrine.orm.entity_manager');
    }

    public function install()
    {
        $installer = new Install($this, Db::getInstance());
        $installed = $installer->install();

        if (!$installed) {
            return false;
        }

        if (!parent::install()) {
            return false;
        }

        if (!$this->registerHook($this->hookToInstall)) {
            return false;
        }

        return true;
    }

    public function uninstall()
    {
        $uninstaller = new Uninstall($this, Db::getInstance());
        $uninstalled = $uninstaller->uninstall();

        if (!$uninstalled) {
            return false;
        }

        return parent::uninstall();
    }

    public function getContent()
    {
        Tools::redirectAdmin(
            $this->get('router')->generate('iletimerkezinotify_configuration')
        );
    }

    /**
     * [shop_name] 
     * [firstname] 
     * [lastname] 
     * [order_id] 
     * [shipping_number] 
     * [order_sum_with_taxes] 
     * [order_sum_without_taxes]
     * [status_name]
     */
    public function hookActionObjectAddAfter($params)
    {
        if (get_class($params['object']) === 'Order') {
            $sms = $this->smsFactory();
            $sms->newOrderCreatedForCustomer($params);
            $sms->newOrderCreatedForAdmins($params);
        }

        if (get_class($params['object']) === 'CustomerMessage') {
            $sms = $sms = $this->smsFactory();
            $sms->newOrderNoteAddedForCustomer($params);
        }
    }

    public function hookActionOrderStatusPostUpdate($params)
    {
        $sms = $this->smsFactory();
        $sms->newOrderStatusChangedForCustomer($params);
    }

    public function hookActionAdminOrdersTrackingNumberUpdate($params)
    {
        $sms = $this->smsFactory();
        $sms->newShippingNumberAddedForCustomer($params);
    }

    public function isUsingNewTranslationSystem()
    {
        return true;
    }

    private function smsFactory()
    {
        $conf = $this->get('prestashop.adapter.legacy.configuration');
        $orm = $this->get('doctrine.orm.entity_manager');

        return new SMS(
            new Api($conf, $orm, $this->context->shop->id),
            $conf,
            $this->context
        );
    }
}