<?php

class IletimerkezinotifyWebhookModuleFrontController extends ModuleFrontController
{
    /*
    Sample hook
    'report' => [
    'id'        => 21112,
    'packet_id' => 2323,
    'status'    => 'DELIVERED',
    'to'        => '+905555555555',
    'body'      => 'Sample message',
    ]
    */
    public function postProcess()
    {
        $payload = file_get_contents("php://input");
        $payload = json_decode($payload, false);

        $db = Db::getInstance();

        $table = _DB_PREFIX_ . 'imn_reports';

        $data = ['status' => pSQL($payload->report->status)];
        $where = 'imn_id = ' . (int) $payload->report->packet_id;

        $result = $db->update($table, $data, $where);

        if (!$result) {
            //@todo: log missed webhook
        }

        die('OK');
    }
}