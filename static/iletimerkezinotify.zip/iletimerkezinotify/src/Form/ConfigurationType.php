<?php

namespace IMN\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class ConfigurationType extends AbstractType
{
    private $context;
    private $translator;
    
    public function __construct($context)
    {
        $this->translator = $context->getTranslator();
    }

    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('apiKey', TextType::class, [
                'label' => $this->translator->trans('API Key', [], 'Modules.Iletimerkezinotify.Admin'),
            ])
            ->add('apiHash', TextType::class, [
                'label' => $this->translator->trans('API Hash', [], 'Modules.Iletimerkezinotify.Admin'),
            ])
            ->add('sender', TextType::class, [
                'label' => $this->translator->trans('Sender', [], 'Modules.Iletimerkezinotify.Admin'),
            ])
            ->add('defaultCountry', ChoiceType::class, [
                'label' => $this->translator->trans('Default Country', [], 'Modules.Iletimerkezinotify.Admin'),
                'choices' => $this->getCountries()
            ])
            ->add('iys', ChoiceType::class, [
                'label' => $this->translator->trans('IYS', [], 'Modules.Iletimerkezinotify.Admin'),
                'choices' => [
                    $this->translator->trans('Yes', [], 'Modules.Iletimerkezinotify.Admin') => 1,
                    $this->translator->trans('No', [], 'Modules.Iletimerkezinotify.Admin') => 0,
                ],
            ])
            ->add('iysList', ChoiceType::class, [
                'label' => $this->translator->trans('IYS List', [], 'Modules.Iletimerkezinotify.Admin'),
                'choices' => [
                    $this->translator->trans('BIREYSEL', [], 'Modules.Iletimerkezinotify.Admin') => 'BIREYSEL',
                    $this->translator->trans('TACIR', [], 'Modules.Iletimerkezinotify.Admin') => 'TACIR',
                ],
            ])
            ->add('admins', TextType::class, [
                'label' => $this->translator->trans('Admin GSM, separate with comma', [], 'Modules.Iletimerkezinotify.Admin'),
            ])
            ->add('isSendOrderNote', ChoiceType::class, [
                'label' => $this->translator->trans('Send Order Note', [], 'Modules.Iletimerkezinotify.Admin'),
                'choices' => [
                    $this->translator->trans('Yes', [], 'Modules.Iletimerkezinotify.Admin') => 1,
                    $this->translator->trans('No', [], 'Modules.Iletimerkezinotify.Admin') => 0,
                ],
            ])
            ->add('customerPhoneField', ChoiceType::class, [
                'label' => $this->translator->trans('Customer Phone Field', [], 'Modules.Iletimerkezinotify.Admin'),
                'choices' => [
                    $this->translator->trans('Phone', [], 'Modules.Iletimerkezinotify.Admin') => 'phone',
                    $this->translator->trans('Phone Mobile', [], 'Modules.Iletimerkezinotify.Admin') => 'phone_mobile',
                ],
            ])
            ->add('webhookAddress', TextType::class, [
                'label' => $this->translator->trans('Webhook Address', [], 'Modules.Iletimerkezinotify.Admin'),
                'disabled' => true
            ]);
    }

    public function getCountries()
    {
        return [
            $this->translator->trans('Turkey', [], 'Modules.Iletimerkezinotify.Admin') => '+90',
            $this->translator->trans('England', [], 'Modules.Iletimerkezinotify.Admin') => '+44'
        ];
    }
}