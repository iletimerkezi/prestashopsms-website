<?php

namespace IMN\Form;

use Context;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use PrestaShop\PrestaShop\Adapter\OrderState\OrderStateDataProvider;

class OrderStatusMessageType extends AbstractType
{
    private $dataProvider;
    private $context;
    private $languageId;
    private $translator;

    public function __construct(OrderStateDataProvider $dataProvider, Context $context, string $languageId)
    {
        $this->dataProvider = $dataProvider;
        $this->translator = $context->getTranslator();
        $this->languageId = $languageId;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('new_order_for_customer', TextareaType::class, [
            'label' => $this->translator->trans('New order for customer', [], 'Modules.Iletimerkezinotify.Admin'),
            'required' => false
        ]);

        $builder->add('new_order_for_admins', TextareaType::class, [
            'label' => $this->translator->trans('New order for admins', [], 'Modules.Iletimerkezinotify.Admin'),
            'required' => false
        ]);

        $orderStatuses = $this->dataProvider->getOrderStates($this->languageId);

        foreach ($orderStatuses as $status) {
            $builder->add('status_' . $status['id_order_state'], TextareaType::class, [
                'label' => $status['name'],
                'required' => false,
            ]);
        }
    }
}