<?php

declare(strict_types=1);

namespace IMN\Grid\Filters;

use IMN\Grid\Definition\Factory\ReportGridDefinitionFactory;
use PrestaShop\PrestaShop\Core\Search\Filters;

class ReportFilters extends Filters
{
    protected $filterId = ReportGridDefinitionFactory::GRID_ID;

    /**
     * {@inheritdoc}
     */
    public static function getDefaults()
    {
        return [
            'limit' => 10,
            'offset' => 0,
            'orderBy' => 'id',
            'sortOrder' => 'DESC',
            'filters' => [],
        ];
    }
}