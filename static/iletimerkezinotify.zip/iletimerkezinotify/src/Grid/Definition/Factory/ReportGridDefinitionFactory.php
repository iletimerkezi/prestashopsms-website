<?php

declare(strict_types=1);

namespace IMN\Grid\Definition\Factory;

use PrestaShop\PrestaShop\Core\Grid\Column\ColumnCollection;
use PrestaShop\PrestaShop\Core\Grid\Column\Type\DataColumn;
use PrestaShop\PrestaShop\Core\Grid\Definition\Factory\AbstractGridDefinitionFactory;
use PrestaShop\PrestaShop\Core\Grid\Filter\FilterCollection;

class ReportGridDefinitionFactory extends AbstractGridDefinitionFactory
{
    const GRID_ID = 'id';

    /**
     * {@inheritdoc}
     */
    protected function getId()
    {
        return self::GRID_ID;
    }

    /**
     * {@inheritdoc}
     */
    protected function getName()
    {
        return $this->trans('Reports', [], 'Modules.IletimerkeziNotify.Admin');
    }

    /**
     * {@inheritdoc}
     */
    protected function getColumns()
    {
        return (new ColumnCollection())
            ->add(
                (new DataColumn('id'))
                    ->setName('ID')
                    ->setOptions([
                        'field' => 'id',
                        'sortable' => false
                    ])
            )
            ->add(
                (new DataColumn('imn_id'))
                    ->setName('IM ID')
                    ->setOptions([
                        'field' => 'imn_id',
                    ])
            )
            ->add(
                (new DataColumn('gsm'))
                    ->setName('GSM')
                    ->setOptions([
                        'field' => 'gsm',
                    ])
            )
            ->add(
                (new DataColumn('message'))
                    ->setName($this->trans('Message', [], 'Modules.Iletimerkezinotify.Admin'))
                    ->setOptions([
                        'field' => 'message',
                    ])
            )
            ->add(
                (new DataColumn('status'))
                    ->setName($this->trans('Status', [], 'Modules.Iletimerkezinotify.Admin'))
                    ->setOptions([
                        'field' => 'status',
                    ])
            )
            ->add(
                (new DataColumn('error_msg'))
                    ->setName($this->trans('Error', [], 'Modules.Iletimerkezinotify.Admin'))
                    ->setOptions([
                        'field' => 'error_msg',
                    ])
            )
            ->add(
                (new DataColumn('created_at'))
                    ->setName($this->trans('Created At', [], 'Modules.Iletimerkezinotify.Admin'))
                    ->setOptions([
                        'field' => 'created_at',
                    ])
            )
            ->add(
                (new DataColumn('updated_at'))
                    ->setName($this->trans('Updated At', [], 'Modules.Iletimerkezinotify.Admin'))
                    ->setOptions([
                        'field' => 'updated_at',
                    ])
            );
    }

    /**
     * {@inheritdoc}
     */
    protected function getFilters()
    {
        return (new FilterCollection());
    }
}