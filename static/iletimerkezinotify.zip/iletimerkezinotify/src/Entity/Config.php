<?php

namespace IMN\Entity;

class Config
{
    protected $apiKey;
    protected $apiHash;
    protected $sender;
    protected $defaultCountry;
    protected $iys;
    protected $iysList;
    protected $admins;
    protected $customerPhoneField;
    protected $isSendOrderNote;
    protected $webhookAddress;

    public function setApiKey($apiKey)
    {
        $this->apiKey = $apiKey;
    }

    public function getApiKey()
    {
        return $this->apiKey;
    }

    public function setApiHash($apiHash)
    {
        $this->apiHash = $apiHash;
    }

    public function getApiHash()
    {
        return $this->apiHash;
    }

    public function setSender($sender)
    {
        $this->sender = $sender;
    }

    public function getSender()
    {
        return $this->sender;
    }

    public function setDefaultCountry($defaultCountry)
    {
        $this->defaultCountry = $defaultCountry;
    }

    public function getDefaultCountry()
    {
        return $this->defaultCountry;
    }

    public function setIys($iys)
    {
        $this->iys = $iys;
    }

    public function getIys()
    {
        return $this->iys;
    }

    public function setIysList($iysList)
    {
        $this->iysList = $iysList;
    }

    public function getIysList()
    {
        return $this->iysList;
    }

    public function setAdmins($admins)
    {
        $this->admins = $admins;
    }

    public function getAdmins()
    {
        return $this->admins;
    }

    public function setCustomerPhoneField($customerPhoneField)
    {
        $this->customerPhoneField = $customerPhoneField;
    }

    public function getCustomerPhoneField()
    {
        return $this->customerPhoneField;
    }

    public function setIsSendOrderNote($isSendOrderNote)
    {
        $this->isSendOrderNote = $isSendOrderNote;
    }

    public function getIsSendOrderNote()
    {
        return $this->isSendOrderNote;
    }

    public function setWebhookAddress($webhookAddress)
    {
        $this->webhookAddress = $webhookAddress;
    }

    public function getWebhookAddress()
    {
        return $this->webhookAddress;
    }
}