<?php

namespace IMN\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table()
 * @ORM\Entity()
 */
class ImnReports
{
    /**
     * @var int
     *
     * @ORM\Id
     * @ORM\Column(name="id", type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
    /**
     * @var int
     *
     * @ORM\Column(name="shop_id", type="integer")
     */
    private $shop_id;
    /**
     * @var int
     *
     * @ORM\Column(name="imn_id", type="integer")
     */
    private $imn_id;
    /**
     * @var string
     *
     * @ORM\Column(name="gsm", type="string", length=64)
     */
    private $gsm;
    /**
     * @var string
     *
     * @ORM\Column(name="message", type="string", length=64)
     */
    private $message;
    /**
     * @var string
     *
     * @ORM\Column(name="status", type="string", length=64)
     */
    private $status;
    /**
     * @var string
     *
     * @ORM\Column(name="error_msg", type="string", length=64)
     */
    private $error_msg;
    /**
     * @var string
     *
     * @ORM\Column(name="created_at", type="string", length=64)
     */
    private $created_at;
    /**
     * @var string
     *
     * @ORM\Column(name="updated_at", type="string", length=64)
     */
    private $updated_at;

    public function setId($id)
    {
        $this->id = $id;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setShopId($shop_id)
    {
        $this->shop_id = $shop_id;
    }

    public function getShopId()
    {
        return $this->shop_id;
    }

    public function setImnId($imn_id)
    {
        $this->imn_id = $imn_id;
    }

    public function getImnId()
    {
        return $this->imn_id;
    }

    public function setGsm($gsm)
    {
        $this->gsm = $gsm;
    }

    public function getGsm()
    {
        return $this->gsm;
    }

    public function setMessage($message)
    {
        $this->message = $message;
    }

    public function getMessage()
    {
        return $this->message;
    }

    public function setStatus($status)
    {
        $this->status = $status;
    }

    public function getStatus()
    {
        return $this->status;
    }

    public function setErrorMsg($error_msg)
    {
        $this->error_msg = $error_msg;
    }

    public function getErrorMsg()
    {
        return $this->error_msg;
    }

    public function setCreatedAt($created_at)
    {
        $this->created_at = $created_at;
    }

    public function getCreatedAt()
    {
        return $this->created_at;
    }

    public function setUpdatedAt($updated_at)
    {
        $this->updated_at = $updated_at;
    }

    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
}