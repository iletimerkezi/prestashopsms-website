<?php

namespace IMN\Controller;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\Request;
use IMN\Form\OrderStatusMessageType;

class TemplateAdminController extends FrameworkBundleAdminController
{
    public function indexAction(Request $request)
    {
        $form = $this->createForm(OrderStatusMessageType::class, $this->getOrderStatusMessages());
        $form->handleRequest($request);
        $handleForm = null;

        if ($form->isSubmitted() && $form->isValid()) {
            $handleForm = $this->handleForm($form->getData());
            if ($handleForm) {
                return $this->redirectToRoute('iletimerkezinotify_templates');
            }
        }

        return $this->render('@Modules/iletimerkezinotify/views/templates/admin/templates.html.twig', [
            'templatesForm' => $form->createView(),
            'resultHandleForm' => null,
            'enableSidebar' => true
        ]);
    }

    private function handleForm($data)
    {
        foreach ($data as $key => $value) {

            if(substr_count($key, '_active') > 0) {
                continue;
            }

            if ($key === 'new_order_for_customer') {
                $this->configuration->set('IMN_NEW_ORDER_FOR_CUSTOMER', $value);
                $this->configuration->set('IMN_NEW_ORDER_FOR_CUSTOMER_ACTIVE', $data['new_order_for_customer_active']);
                continue;
            }

            if ($key === 'new_order_for_admins') {
                $this->configuration->set('IMN_NEW_ORDER_FOR_ADMINS', $value);
                $this->configuration->set('IMN_NEW_ORDER_FOR_ADMINS_ACTIVE', $data['new_order_for_admins_active']);
                continue;
            }

            if ($key === 'new_shipping_number_added') {
                $this->configuration->set('IMN_NEW_SHIPPING_NUMBER_ADDED', $value);
                $this->configuration->set('IMN_NEW_SHIPPING_NUMBER_ADDED_ACTIVE', $data['new_shipping_number_added_active']);
                continue;
            }

            $parts = explode('_', $key);
            $this->configuration->set('IMN_ORDER_STATUS_' . $parts[1], $value);
            $this->configuration->set('IMN_ORDER_STATUS_' . $parts[1] . '_ACTIVE', $data[$key.'_active']);
        }

        return true;
    }

    private function getOrderStatusMessages()
    {
        $data = [];

        $data['new_order_for_customer'] = $this->configuration->get('IMN_NEW_ORDER_FOR_CUSTOMER');
        $data['new_order_for_customer_active'] = (bool) $this->configuration->get('IMN_NEW_ORDER_FOR_CUSTOMER_ACTIVE', false);
        $data['new_order_for_admins'] = $this->configuration->get('IMN_NEW_ORDER_FOR_ADMINS');
        $data['new_order_for_admins_active'] = (bool) $this->configuration->get('IMN_NEW_ORDER_FOR_ADMINS_ACTIVE', false);        
        $data['new_shipping_number_added'] = $this->configuration->get('IMN_NEW_SHIPPING_NUMBER_ADDED');
        $data['new_shipping_number_added_active'] = (bool) $this->configuration->get('IMN_NEW_SHIPPING_NUMBER_ADDED_ACTIVE', false);


        $provider = $this->get('prestashop.adapter.data_provider.order_state');
        $statuses = $provider->getOrderStates($this->getContext()->language->id);

        foreach ($statuses as $status) {
            $data['status_' . $status['id_order_state']] = $this->configuration->get('IMN_ORDER_STATUS_' . $status['id_order_state']);
            $data['status_' . $status['id_order_state']. '_active'] = (bool) $this->configuration->get('IMN_ORDER_STATUS_' . $status['id_order_state'].'_ACTIVE', false);
        }

        return $data;
    }
}