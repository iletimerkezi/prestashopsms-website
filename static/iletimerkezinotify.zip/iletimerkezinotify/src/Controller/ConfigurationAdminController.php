<?php

namespace IMN\Controller;

use Context;
use IMN\Entity\Config;
use IMN\Form\ConfigurationType;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\Request;

class ConfigurationAdminController extends FrameworkBundleAdminController
{
    public function indexAction(Request $request)
    {
        $form = $this->createForm(ConfigurationType::class, $this->getConfig());
        $form->handleRequest($request);
        $handleForm = null;

        if ($form->isSubmitted() && $form->isValid()) {
            $handleForm = $this->handleForm($form->getData());
            if ($handleForm) {
                return $this->redirectToRoute('iletimerkezinotify_configuration');
            }
        }

        return $this->render('@Modules/iletimerkezinotify/views/templates/admin/configure.html.twig', [
            'configurationForm' => $form->createView(),
            'resultHandleForm' => $handleForm,
            'enableSidebar' => true
        ]);
    }

    private function handleForm(Config $config)
    {
        $this->configuration->set('IMN_API_KEY', $config->getApiKey());
        $this->configuration->set('IMN_API_HASH', $config->getApiHash());
        $this->configuration->set('IMN_SENDER', $config->getSender());
        $this->configuration->set('IMN_DEFAULT_COUNTRY', $config->getDefaultCountry());
        $this->configuration->set('IMN_IYS', $config->getIys());
        $this->configuration->set('IMN_IYS_LIST', $config->getIysList());
        $this->configuration->set('IMN_ADMINS', $config->getAdmins());
        $this->configuration->set('IMN_IS_SEND_ORDER_NOTE', $config->getIsSendOrderNote());
        $this->configuration->set('IMN_CUSTOMER_PHONE_FIELD', $config->getCustomerPhoneField());

        return true;
    }

    private function getConfig()
    {
        $config = new Config();
        $config->setApiKey($this->configuration->get('IMN_API_KEY'));
        $config->setApiHash($this->configuration->get('IMN_API_HASH'));
        $config->setSender($this->configuration->get('IMN_SENDER'));
        $config->setDefaultCountry($this->configuration->get('IMN_DEFAULT_COUNTRY'));
        $config->setIys($this->configuration->get('IMN_IYS'));
        $config->setIysList($this->configuration->get('IMN_IYS_LIST'));
        $config->setAdmins($this->configuration->get('IMN_ADMINS'));
        $config->setIsSendOrderNote($this->configuration->get('IMN_IS_SEND_ORDER_NOTE'));
        $config->setCustomerPhoneField($this->configuration->get('IMN_CUSTOMER_PHONE_FIELD'));

        $context = Context::getContext();
        $config->setWebhookAddress($context->link->getBaseLink() . 'index.php?fc=module&module=iletimerkezinotify&controller=webhook');

        return $config;
    }
}