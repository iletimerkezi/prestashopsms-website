<?php

namespace IMN\Controller;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use IMN\Grid\Filters\ReportFilters;

class ReportAdminController extends FrameworkBundleAdminController
{
    public function indexAction(ReportFilters $filters)
    {
        $reportGridFactory = $this->get('iletimerkezinotify.grid.factory.reports');
        $reportGrid = $reportGridFactory->getGrid($filters);

        return $this->render(
            '@Modules/iletimerkezinotify/views/templates/admin/report.html.twig',
            [
                'enableSidebar' => true,
                'layoutTitle' => $this->trans('Reports listing', 'Modules.Demogrid.Admin'),
                'reportGrid' => $this->presentGrid($reportGrid),
            ]
        );
    }
}