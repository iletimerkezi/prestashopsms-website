<?php

namespace IMN\Module;

class Install
{
    private $module;
    private $db;
    private $translator;

    public function __construct(\Iletimerkezinotify $module, \Db $db)
    {
        $this->module = $module;
        $this->db = $db;
        $this->translator = $this->module->getTranslator();
    }

    public function install()
    {
        if (!$this->installDatabaseTables()) {
            return false;
        }

        if (!$this->installInMenu()) {
            return false;
        }

        return true;
    }

    private function installDatabaseTables()
    {
        $migrate = new Migrate($this->module, $this->db);

        return $migrate->runMigration('create_imn_reports_table');
    }

    private function installInMenu()
    {
        $installTabCompleted = true;

        foreach ($this->getTabs() as $tab) {
            try {
                $installTabCompleted = $installTabCompleted && $this->installTab(
                    $tab['className'],
                    $tab['parent'],
                    $tab['name'],
                    $tab['module'],
                    $tab['active'],
                    $tab['icon']
                );
            } catch (\Exception $e) {
                return false;
            }
        }

        return $installTabCompleted;
    }

    private function installTab($className, $parent, $name, $module, $active, $icon)
    {
        if (\Tab::getIdFromClassName($className)) {
            return true;
        }

        $idParent = is_int($parent) ? $parent : \Tab::getIdFromClassName($parent);

        $moduleTab = new \Tab();
        $moduleTab->class_name = $className;
        $moduleTab->id_parent = $idParent;
        $moduleTab->module = $module;
        $moduleTab->active = $active;

        if (property_exists($moduleTab, 'icon')) {
            $moduleTab->icon = $icon;
        }

        $languages = \Language::getLanguages(true);
        foreach ($languages as $language) {
            $moduleTab->name[$language['id_lang']] = $name;
        }

        return $moduleTab->add();
    }

    private function getTabs()
    {
        return [
            [
                'className' => 'Marketing',
                'parent' => 'IMPROVE',
                'name' => $this->translator->trans('Marketing', [], 'Modules.Iletimerkezinotify.Admin'),
                'module' => '',
                'active' => true,
                'icon' => 'campaign',
            ],
            [
                'className' => 'IMNMenuItem',
                'parent' => 'Marketing',
                'name' => 'iletiMerkezi Notify',
                'module' => 'iletimerkezinotify',
                'active' => true,
                'icon' => '',
            ],
            [
                'className' => 'IMNConfigurationTab',
                'parent' => 'IMNMenuItem',
                'name' => $this->translator->trans('Configuration', [], 'Modules.Iletimerkezinotify.Admin'),
                'module' => 'iletimerkezinotify',
                'active' => true,
                'icon' => '',
            ],
            [
                'className' => 'IMNTemplatesTab',
                'parent' => 'IMNMenuItem',
                'name' => $this->translator->trans('Templates', [], 'Modules.Iletimerkezinotify.Admin'),
                'module' => 'iletimerkezinotify',
                'active' => true,
                'icon' => '',
            ],
            [
                'className' => 'IMNReportsTab',
                'parent' => 'IMNMenuItem',
                'name' => $this->translator->trans('Reports', [], 'Modules.Iletimerkezinotify.Admin'),
                'module' => 'iletimerkezinotify',
                'active' => true,
                'icon' => '',
            ],
        ];
    }
}