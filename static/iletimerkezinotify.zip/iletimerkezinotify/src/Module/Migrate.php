<?php

namespace IMN\Module;

use Tools;

class Migrate
{
    private $module;
    private $db;

    public function __construct(\Iletimerkezinotify $module, \Db $db)
    {
        $this->module = $module;
        $this->db = $db;
    }

    public function runMigration($migration)
    {
        $dbInstallFile = "{$this->module->getLocalPath()}/sql/{$migration}.sql";

        if (!file_exists($dbInstallFile)) {
            return false;
        }

        $sql = Tools::file_get_contents($dbInstallFile);

        if (empty($sql) || !is_string($sql)) {
            return false;
        }

        $sql = str_replace(['PREFIX_', 'ENGINE_TYPE'], [_DB_PREFIX_, _MYSQL_ENGINE_], $sql);
        $sql = preg_split("/;\s*[\r\n]+/", trim($sql));

        if (!empty($sql)) {
            foreach ($sql as $query) {
                if (!$this->db->execute($query)) {
                    return false;
                }
            }
        }

        return true;
    }

}