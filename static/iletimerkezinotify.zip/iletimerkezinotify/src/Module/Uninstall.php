<?php

namespace IMN\Module;

class Uninstall
{
    private $module;
    private $db;

    public function __construct(\Iletimerkezinotify $module, \Db $db)
    {
        $this->module = $module;
        $this->db = $db;
    }

    public function uninstall()
    {
        if (!$this->uninstallDatabaseTables()) {
            return false;
        }

        if (!$this->uninstallMenu()) {
            return false;
        }

        return true;
    }

    private function uninstallDatabaseTables()
    {
        $migrate = new Migrate($this->module, $this->db);

        return $migrate->runMigration('uninstall');
    }

    private function uninstallMenu()
    {
        foreach ($this->getTabs() as $tab) {
            $this->deleteAdminTab($tab['className']);
        }

        return true;
    }

    private function uninstallConfiguration()
    {
        $configs = [
            'IMN_API_KEY', 'IMN_API_HASH', 'IMN_SENDER', 'IMN_DEFAULT_COUNTRY',
            'IMN_IYS', 'IMN_IYS_LIST', 'IMN_ADMINS', 'IMN_IS_SEND_ORDER_NOTE',
            'IMN_CUSTOMER_PHONE_FIELD', 'IMN_NEW_ORDER_FOR_CUSTOMER', 'IMN_NEW_ORDER_FOR_ADMINS',
            'IMN_IS_SEND_ORDER_NOTE'
        ];

        $provider = $this->module->get('prestashop.adapter.data_provider.order_state');
        $statuses = $provider->getOrderStates($this->module->context->language->id);

        foreach ($statuses as $status) {
            $configs[] = 'IMN_ORDER_STATUS_' . $status['id_order_state'];
        }

        foreach ($configs as $config) {
            \Configuration::deleteByName($config);
        }

    }

    private function deleteAdminTab($controllerName)
    {
        $tabId = (int) \Tab::getIdFromClassName($controllerName);
        if ($tabId) {
            (new \Tab($tabId))->delete();
        }
    }

    private function getTabs()
    {
        return [
            [
                'className' => 'Marketing',
                'parent' => 'IMPROVE',
                'name' => 'Marketing',
                'module' => '',
                'active' => true,
                'icon' => 'campaign',
            ],
            [
                'className' => 'IMNMenuItem',
                'parent' => 'Marketing',
                'name' => 'iletiMerkezi Notify',
                'module' => 'iletimerkezinotify',
                'active' => true,
                'icon' => '',
            ],
            [
                'className' => 'IMNConfigurationTab',
                'parent' => 'IMNMenuItem',
                'name' => 'Configuration',
                'module' => 'iletimerkezinotify',
                'active' => true,
                'icon' => '',
            ],
            [
                'className' => 'IMNTemplatesTab',
                'parent' => 'IMNMenuItem',
                'name' => 'Templates',
                'module' => 'iletimerkezinotify',
                'active' => true,
                'icon' => '',
            ],
            [
                'className' => 'IMNReportsTab',
                'parent' => 'IMNMenuItem',
                'name' => 'Reports',
                'module' => 'iletimerkezinotify',
                'active' => true,
                'icon' => '',
            ],
        ];
    }
}