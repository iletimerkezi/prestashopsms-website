<?php

namespace IMN\SMS;

class Message
{
    public static function merge(string $template, array $variables)
    {
        foreach ($variables as $key => $value) {
            $template = str_replace("[$key]", $value, $template);
        }

        return $template;
    }
}