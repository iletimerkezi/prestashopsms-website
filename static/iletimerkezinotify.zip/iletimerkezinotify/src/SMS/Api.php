<?php

namespace IMN\SMS;

use PrestaShop\PrestaShop\Adapter\Configuration;
use IMN\Entity\ImnReports;

class Api
{
    private $url = 'https://api.iletimerkezi.com/v1/send-sms/json';
    private $to;
    private $message;
    private $configuration;
    private $entityManager;
    private $shopId;
    public function __construct(Configuration $configuration, $entityManager, $shopId)
    {
        $this->configuration = $configuration;
        $this->entityManager = $entityManager;
        $this->shopId = $shopId;
    }

    public function setTo($to)
    {
        $this->to = $to;
    }

    public function getTo()
    {
        return $this->to;
    }

    public function setMessage($message)
    {
        $this->message = $message;
    }

    public function getMessage()
    {
        return $this->message;
    }

    public function send()
    {
        $data = [
            'request' => [
                'authentication' => [
                    'key' => $this->configuration->get('IMN_API_KEY'),
                    'hash' => $this->configuration->get('IMN_API_HASH')
                ],
                'order' => [
                    'sender' => $this->configuration->get('IMN_SENDER'),
                    'sendDateTime' => [],
                    'iys' => $this->configuration->get('IMN_IYS'),
                    'iysList' => $this->configuration->get('IMN_IYS_LIST'),
                    'message' => [
                        'text' => $this->getMessage(),
                        'receipents' => [
                            'number' => [$this->getTo()]
                        ]
                    ]
                ]
            ]
        ];

        $report = new ImnReports();
        $report->setShopId($this->shopId);
        $report->setGsm($this->getTo());
        $report->setMessage($this->getMessage());
        $report->setCreatedAt(date('Y-m-d H:i:s'));
        $report->setUpdatedAt(date('Y-m-d H:i:s'));

        return $this->request($data, $report);
    }

    private function request($data, $report)
    {
        $ch = curl_init();
        if (false === $ch) {
            $report->setErrorMsg('PHP Curl extension is not installed');
            $report->setStatus('error');

            $this->entityManager->persist($report);
            $this->entityManager->flush();

            return false;
        }

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type' => 'application/json']);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 180);
        curl_setopt($ch, CURLOPT_URL, $this->url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $result = curl_exec($ch);
        $result = json_decode($result);

        if ($result->response->status->code !== 200) {
            $report->setErrorMsg($result->response->status->message);
            $report->setStatus('error');

            $this->entityManager->persist($report);
            $this->entityManager->flush();

            return false;
        }

        $report->setStatus('success');
        $report->setImnId($result->response->order->id);

        $this->entityManager->persist($report);
        $this->entityManager->flush();

        return true;
    }
}