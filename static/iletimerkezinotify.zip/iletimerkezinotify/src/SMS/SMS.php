<?php

namespace IMN\SMS;

use Tools;
use Address;
use Order;
use CustomerThread;

class SMS
{
    private $api;
    private $configuration;
    private $context;

    public function __construct($api, $configuration, $context)
    {
        $this->api = $api;
        $this->configuration = $configuration;
        $this->context = $context;
    }

    public function newOrderCreatedForCustomer($params)
    {
        $this->api->setTo($this->getCustomerPhone($params['object']->id_address_delivery));
        $this->api->setMessage(Message::merge(
            $this->configuration->get('IMN_NEW_ORDER_FOR_CUSTOMER'),
            $this->getVariables($params['object'])
        ));

        $this->api->send();
    }

    public function newOrderCreatedForAdmins($params)
    {
        $admins = $this->configuration->get('IMN_ADMINS');

        foreach (explode(',', $admins) as $admin) {
            $this->api->setTo($admin);
            $this->api->setMessage(Message::merge(
                $this->configuration->get('IMN_NEW_ORDER_FOR_ADMINS'),
                $this->getVariables($params['object'])
            ));

            $this->api->send();
        }
    }

    public function newOrderStatusChangedForCustomer($params)
    {
        $order = new Order($params['id_order']);

        $this->api->setTo($this->getCustomerPhone($order->id_address_delivery));
        $this->api->setMessage(Message::merge(
            $this->configuration->get('IMN_ORDER_STATUS_' . $params['newOrderStatus']->id),
            array_merge(
                $this->getVariables($order),
                ['status_name' => $params['newOrderStatus']->name]
            )));

        $this->api->send();
    }

    public function newShippingNumberAddedForCustomer($params)
    {
        $this->api->setTo($this->getCustomerPhone($params['order']->id_address_delivery));
        $this->api->setMessage(Message::merge(
            $this->configuration->get('IMN_NEW_ORDER_FOR_CUSTOMER'),
            $this->getVariables($params['order'])
        ));

        $this->api->send();
    }

    public function newOrderNoteAddedForCustomer($params)
    {
        if ($params['object']->private || !$this->configuration->get('IMN_IS_SEND_ORDER_NOTE')) {
            return;
        }

        $thread = new CustomerThread($params['object']->id_customer_thread);
        $order = new Order($thread->id_order);

        $this->api->setTo($this->getCustomerPhone($order->id_address_delivery));
        $this->api->setMessage(Message::merge(
            $params['object']->message,
            $this->getVariables($order)
        ));

        $this->api->send();
    }

    private function getCustomerPhone($id_address_delivery)
    {
        $address = new Address($id_address_delivery);
        $field = $this->configuration->get('IMN_CUSTOMER_PHONE_FIELD');

        if (is_null($field) || empty($field)) {
            $field = 'phone';
        }

        return $address->$field;
    }

    private function getVariables($order)
    {
        return [
            'shop_name' => $this->context->shop->name,
            'firstname' => $order->getCustomer()->firstname,
            'lastname' => $order->getCustomer()->lastname,
            'order_id' => $order->id,
            'shipping_number' => $order->getShippingNumber(),
            'order_sum_with_taxes' => $this->roundPrice($order->getTotalProductsWithTaxes()),
            'order_sum_without_taxes' => $this->roundPrice($order->getTotalProductsWithoutTaxes())
        ];
    }

    private function roundPrice($price)
    {
        return Tools::ps_round($price, $this->context->getComputingPrecision());
    }
}